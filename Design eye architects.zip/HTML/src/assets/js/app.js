/* Template Name: Floti - Tailwind CSS Authentication Pages Template
  Author: Zoyothemes
  Email: zoyothemes@gmail.com
  Website: http://zoyothemes.com/
  Version: 1.0.0
  Created: February 2024
  File: Main Css File
*/

/*================================
 *      02.  lucide Js           *
 ================================*/
lucide.createIcons();
